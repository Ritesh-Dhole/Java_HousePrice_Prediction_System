package org.house.predict.service;

import org.house.predict.model.PropertyModel;
import org.house.predict.repository.PropertyRepository;
import java.util.*;
public class PropertyService 
{
	PropertyRepository propRepo = new PropertyRepository();
	public boolean isAddNewProperty(PropertyModel model)	
	{
		return propRepo.isAddNewProperty(model);
	}
	
	public List<Object[]> getAreaWisePropertyCount(String cityName)
	{
		return propRepo.getAreaWisePropertyCount(cityName);
	}
}
