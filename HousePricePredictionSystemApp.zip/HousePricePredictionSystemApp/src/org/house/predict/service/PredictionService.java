package org.house.predict.service;

import org.house.predict.repository.PredictionRepository;

public class PredictionService 
{
	PredictionRepository predRepo = new PredictionRepository();
	public int getMinOfX(int areaId)
	{
		return predRepo.getMinOfX(areaId);
	}
}
