package org.house.predict.service;

import java.util.*;
import org.house.predict.model.AreaMasterModel;
import org.house.predict.model.CityMasterModel;
import org.house.predict.repository.*;
public class CityMasterService 
{
//	Service class contains object of repository class so we create object of repository class here
	CityMasterRepository cityrepo = new CityMasterRepository();
	
	public boolean isAddCity(CityMasterModel model)
	{
		boolean b = cityrepo.isAddNewCity(model);
		return b;
	}
	
	public List<CityMasterModel> getAllCities()
	{
//		List<CityMasterModel> list = cityrepo.getAllCities();
//		return list; 
		return cityrepo.getAllCities();		//shorthand of above two lines
	}
	
	public boolean isAddbulkCities()
	{
		return cityrepo.isAddBulkCities();
	}
	
	public int getCityId(String cityname)
	{
		return cityrepo.getCityId(cityname);
	}
	
	public int getAreaIdAutomatic()
	{
		return cityrepo.getAreaIdAutomatic();
	}
	
	public boolean isAddArea(AreaMasterModel areamodel)
	{
		return cityrepo.isAddArea(areamodel);
	}
	
	public LinkedHashMap<String,Integer>getCityWiseCount()
	{
		return this.cityrepo.getCityWiseCount();
	}
	
	public LinkedHashMap<String,ArrayList<String>> getCityWiseAreaNames()
	{
		return this.cityrepo.getCityWiseAreaNames();
	}
	
	public int getAreaId(AreaMasterModel model)
	{
		return this.cityrepo.getAreaIdByName(model);
	}
	
	public LinkedHashMap<String,ArrayList<String>> getAreasByCityName(String cityName)
	{
		return cityrepo.getAreasByCityName(cityName);
	}
}
