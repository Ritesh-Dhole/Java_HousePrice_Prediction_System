package org.house.predict.client;

import java.util.*;
import org.house.predict.service.*;
import org.house.predict.model.*;
public class PredictionClientApplication {

	public static void main(String[] args) 
	{
		CityMasterService cms = new CityMasterService();
		AreaSquareFeetService areaSq = new AreaSquareFeetService();
		AmenityService amService = new AmenityService();
		PropertyService propService = new PropertyService();
		PredictionService predService = new PredictionService();
		
		do
		{
			Scanner xyz = new Scanner (System.in);
			int choice;
			System.out.println("1: Add New City");
			System.out.println("2: View All City");
			System.out.println("3: Add New Bulk Cities");
			System.out.println("4: Add New Area");
			System.out.println("5: CityWise Area Count");
			System.out.println("6: CityWise Area Names");
			System.out.println("7: Add Square Feet Area of Property");
			System.out.println("8: Add Amenities");
			System.out.println("9: Add Properties");
			System.out.println("10: Find AreaWise Property Count");
			System.out.println("11: Predict Property Price");
			
			System.out.println("Enter your choice");
			choice = xyz.nextInt();
			switch(choice)
			{
			case 1:
		     	System.out.println("Enter City Name");
		     	xyz.nextLine();
		     	String cityName = xyz.nextLine();
		     	CityMasterModel citymodel = new CityMasterModel();
		     	citymodel.setCityName(cityName);
		     	boolean b = cms.isAddCity(citymodel);
		     	if (b)
		     	{
		     		System.out.println("New City Added Successfully in Database.......!");
		     	}
		     	else
		     	{
		     		System.out.println("New City not Added in Database.......?");
		     	}
			break;
			
			case 2:
				List<CityMasterModel> list = cms.getAllCities();
				if (list!=null)
				{
					list.forEach((m)->System.out.println(m.getCityId()+"\t"+m.getCityName()));
//					m is nothing but model and this expression is known as lambda expression
				}
				else
				{
					System.out.println("There is no City present...........?");
				}
			break;	
			
			case 3:
				b = cms.isAddbulkCities();
				if (b)
				{
					System.out.println("Bulk City Added Successfully......!");
				}
				else
				{
					System.out.println("Some Problem is there.......?");
				} 
			break;
			
			case 4:
				xyz.nextLine(); 
				System.out.println("Enter City Name");
				String cityname = xyz.nextLine();
				int cityId = cms.getCityId(cityname);		//get cityid by cityname
				System.out.println("CityId is "+cityId);
				if (cityId!=-1)
				{
					System.out.println("Enter area name");
					String areaName = xyz.nextLine();
					int areaId = cms.getAreaIdAutomatic();
//					System.out.println("cityId"+"\t"+"areaId"+"\t"+"areaName");
//					System.out.println(cityId+"\t"+areaId+"\t"+areaName);
					AreaMasterModel areamodel = new AreaMasterModel();
					areamodel.setCityId(cityId);
					areamodel.setAreaId(areaId);
					areamodel.setAreaName(areaName);
					 
				    b = cms.isAddArea(areamodel);
					if (b)
					{
						 System.out.println("Area added Successfully......");
					}
					else
					{
						System.out.println("Area not Added.....");
					}
				}
				else
				{
					System.out.println("City not present in Database......!");
					System.out.println("Do you want add this city in database Table ?");
					String msg=xyz.nextLine();
					if(msg.equals("yes"))		//this logic is copied from case 1 
					{
//					    cityName = xyz.nextLine();
				        citymodel = new CityMasterModel();
				     	citymodel.setCityName(cityname);		//cityname initialized above 
				        b = cms.isAddCity(citymodel);
				     	if (b)
				     	{
				     		System.out.println("New City Added Successfully in Database.......!");
				     	}
				     	else
				     	{
				     		System.out.println("New City not Added in Database.......?");
				     	}
					}
					else
					{
						System.out.println("Thank You....!");
					}
				}
			break;
			
			case 5:
				LinkedHashMap <String,Integer> map = cms.getCityWiseCount();
				Set<Map.Entry<String,Integer>> s = map.entrySet();
				for(Map.Entry<String,Integer> m:s)
				{
					System.out.println(m.getKey()+"\t\t"+m.getValue());
				}
			break;
			
			case 6:
			    LinkedHashMap<String,ArrayList<String>> areaNames = cms.getCityWiseAreaNames();
			    Set<Map.Entry<String,ArrayList<String>>> set = areaNames.entrySet(); 
			    for(Map.Entry<String,ArrayList<String>> m:set)
			    {
			    	ArrayList <String> values = m.getValue();
			    	if (values.size()>0)
			    	{
			    		System.out.println("CityName - "+m.getKey());		//CityName
			    		System.out.println("____________________________________");
			    		for(String areaName : values)
				    	{
				    		System.out.println(areaName);		//AreaNames 
				    	}
			    		System.out.println("");
			    	}
			    }
			break;
			
			case 7:
				System.out.println("Enter Area Value in Square Feet");
				int sqFeet = xyz.nextInt();
				AreaSquareFeetModel areaFeetModel = new AreaSquareFeetModel();
				areaFeetModel.setSquareFeet(sqFeet);
			    b = areaSq.isAddSquareFeet(areaFeetModel);
			    if (b)
			    {
			    	System.out.println("Square Feet Added Successfully in Database Table....!");
			    }
			    else
			    {
			    	System.out.println("Square Feet not added...?");
			    }
			break;
			
			case 8:
				xyz.nextLine();
				System.out.println("Enter Amenity Name");
				String name=xyz.next();
				AmenityModel amenitymodel = new AmenityModel();
				amenitymodel.setName(name);
				b = amService.isAddAmenity(amenitymodel);
				if(b)
				{					
					System.out.println("New Amenity Added Succesfully in Database.....!");
					System.out.println("_____________________________________________________");
				}
				else
				{
					System.out.println("No Amenity Added...?");
				}
			break;
			
			case 9:
				xyz.nextLine();
				System.out.println("Enter City Name");
				cityName = xyz.nextLine();
				System.out.println("Enter Area Name");
				String areaName = xyz.nextLine();
				System.out.println("Enter Address of the Property");
				String propertyAddress = xyz.nextLine();
				System.out.println("Enter Land Area");
				int landArea = xyz.nextInt();
				System.out.println("Enter Number of BedRoom");
				int nBed = xyz.nextInt();
				System.out.println("Enter Number of BathRoom");
				int nBath = xyz.nextInt();
			    cityId = cms.getCityId(cityName);
			    AreaMasterModel areaModel = new AreaMasterModel();
			    areaModel.setCityName(cityName);
			    areaModel.setAreaName(areaName);
			    int areaId = cms.getAreaId(areaModel);
			    System.out.println("Area Id is :"+areaId);
			    areaModel.setCityId(cityId);
			    areaModel.setAreaId(areaId);
			    int sqId = areaSq.getSquareFeetId(landArea);
			    if(sqId == -1)
			    {
			    	System.out.println("There is Some Exception");
			    }
			    if(sqId == 0)
			    {
			    	System.out.println("SquareFeet Area is not Present. Do You want to add New Area...!");
			    }
			    	List<AmenityModel> amenityList = new ArrayList<AmenityModel>();
				    String str="";
				    do
				    {
				    	System.out.println("Enter Amenity Name");
				    	String amName = xyz.next();
				    	AmenityModel amModel = new AmenityModel();
				    	int amId = new AmenityService().getAmenityId(amName);
				    	amModel.setName(amName);
				    	amModel.setId(amId);
				    	amenityList.add(amModel);
				    	System.out.println("Do You want to add More Amenities");
				    	str = xyz.next();
				    }
				    while(str.equals("yes") || str.equals("YES")); 
			    
				    PropertyModel propModel = new PropertyModel();
				    propModel.setAreaModel(areaModel);		//this areaModel Object contains cityName,areaName,cityId and areaId solely
				    propModel.setAddress(propertyAddress);
				    propModel.setNBed(nBed);
				    propModel.setNBath(nBath);
				    areaFeetModel = new AreaSquareFeetModel();
				    areaFeetModel.setSquareFeet(landArea);
				    areaFeetModel.setId(sqId);
				    propModel.setSqModel(areaFeetModel);
				    propModel.setList(amenityList);
				    System.out.println("Enter Price of Property");
				    int price = xyz.nextInt();
//				    xyz.nextLine();
//				    String rDate = xyz.nextLine();
				    DealModel dModel = new DealModel();
				    dModel.setPrice(price);
//				    dModel.setDate(rDate); 
				    propModel.setDealModel(dModel);
				    b = propService.isAddNewProperty(propModel);
				    if(b)
				    {
				    	System.out.println("New Property Added Successfully....!");
				    }
				    else
				    {
				    	System.out.println("There is some Problem...?");
				    }
			break;
			
			case 10:
				System.out.println("Enter City Name");
				xyz.nextLine();
				cityName = xyz.next();
				List<Object[]> propCountlist = propService.getAreaWisePropertyCount(cityName);
				System.out.println("AreaName"+"\t"+"Property Count");
				for(Object obj[] : propCountlist)
				{
					System.out.println(obj[0]+"\t\t"+obj[1]);
				}
			break;
			
			case 11:
				System.out.println("Enter City Name");
				xyz.nextLine();
				cityName = xyz.next();
				cityId = cms.getCityId(cityName);
				LinkedHashMap<String,ArrayList<String>> areaList = cms.getAreasByCityName(cityName);
				if(areaList.size()>0)
				{
					System.out.println("Select area for your Property");
					Set<Map.Entry<String, ArrayList<String>>> areaSet = areaList.entrySet();
					for(Map.Entry<String, ArrayList<String>> mArea : areaSet)
					{
						ArrayList<String> areaNameList = mArea.getValue();
						for(String areaname : areaNameList)
						{
							System.out.println(areaname);
						}
					}
					System.out.println("Enter Area Name");
					String userArea = xyz.next();
					AreaMasterModel userAreaModel = new AreaMasterModel();
					userAreaModel.setCityName(cityName);
					userAreaModel.setAreaName(userArea);
					int userAreaId = cms.getAreaId(userAreaModel);
					
					float meanofX = predService.getMinOfX(userAreaId);
					System.out.println("_________________________");
					System.out.println("Mean of x "+ meanofX);
					System.out.println("_________________________");
					
				} 
				else
				{
					System.out.println("No city found in Database");
				}
			break;
			
			default :
				System.out.println("Wrong Choice");
			}
		}
		while(true);
	}

}
