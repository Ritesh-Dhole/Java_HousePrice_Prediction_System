package org.house.predict.model;

import java.util.*; 
public class PropertyModel 
{
	private int pid;
	private String address;
	private int NBed;
	private int NBath;
//	below statements are called as HAS-A relationship with PropertyModel
	private AreaMasterModel areaModel;
	private AreaSquareFeetModel sqModel;
	private List<AmenityModel> list;
	private DealModel dealModel;
//	private CityMasterModel cityModel;
//	we not need to create cityMasterModel object because areaMasterModel extends cityMasterModel class
	
	
	public int getPid() {
		return pid;
	}
	public DealModel getDealModel() {
		return dealModel;
	}
	public void setDealModel(DealModel dealModel) {
		this.dealModel = dealModel;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getNBed() {
		return NBed;
	}
	public void setNBed(int nBed) {
		NBed = nBed;
	}
	public int getNBath() {
		return NBath;
	}
	public void setNBath(int nBath) {
		NBath = nBath;
	}
	public AreaMasterModel getAreaModel() {
		return areaModel;
	}
	public void setAreaModel(AreaMasterModel areaModel) {
		this.areaModel = areaModel;
	} 
	public AreaSquareFeetModel getSqModel() {
		return sqModel;
	}
	public void setSqModel(AreaSquareFeetModel sqModel) {
		this.sqModel = sqModel;
	}
	public List<AmenityModel> getList() {
		return list;
	}
	public void setList(List<AmenityModel> list) {
		this.list = list;
	}
	
}
 