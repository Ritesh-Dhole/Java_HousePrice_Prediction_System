 package org.house.predict.model;

public class AreaMasterModel extends CityMasterModel
{
	private int areaId;
	public int getAreaId() {
		return areaId;
	}
	public void setAreaId(int areaId) {
		this.areaId = areaId;
	}
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	private String areaName;
	
}
