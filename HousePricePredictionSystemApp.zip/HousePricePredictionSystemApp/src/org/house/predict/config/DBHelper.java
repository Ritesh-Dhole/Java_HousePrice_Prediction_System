package org.house.predict.config;
import java.sql.*;
//DBHelper class must be inherited in every class because we have created all references here and this is called data security which we achieved by
//data encapsulation because our connection objects are not accessible directly in any class and just pass the references
public class DBHelper 
{
	protected DBConfig db = DBConfig.getInstance();
    //we provide protected so that logic is accessible in the child class 
	protected Connection con = DBConfig.getConnection();
    //this is accessed from DBConfig to pass Connection method in every class	
	protected PreparedStatement stmt = DBConfig.getStatement();
	//this is accessed from DBConfig to pass PreparedStatement  method in every class	
	protected ResultSet rs = DBConfig.getResultSet();
	//this is accessed from DBConfig to pass ResultSet method in every class	

}
