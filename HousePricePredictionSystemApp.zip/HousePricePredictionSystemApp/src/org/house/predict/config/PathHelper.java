package org.house.predict.config;
//this is the PathHelper class where we store our all paths of the project only once and reuse it multiple times whenever required
import java.io.*;

public class PathHelper 
{
	public static FileInputStream fin=null;
//	we made FileInputStream as public so that it is accessible outside of the package and static can run before the main method also 
//	public static File f=null;
	public static File f = new File(".");
//	null value is replaced by f value written below in line 15
	public static String path = (f.getAbsolutePath().substring(0,f.getAbsolutePath().length()-1))+"src\\";
	
	static{
//		f = new File(".");
		String path1= path+"db.properties";
		try 
		{
//			FileInputStream fin = new FileInputStream(path);
			fin=new FileInputStream(path1);
//			this FileInputStream we need to declare out of this static block with null value once
		} 
		catch (FileNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
}
