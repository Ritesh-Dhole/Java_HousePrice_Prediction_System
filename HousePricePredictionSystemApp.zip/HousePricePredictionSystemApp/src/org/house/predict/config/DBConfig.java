package org.house.predict.config;

import java.sql.*;
import java.io.*;
import java.util.*;

import com.mysql.cj.jdbc.Driver;
public class DBConfig 
{
//	below variables connection,PreparedStatement and ResultSet will get access Specifier as per situation if protected then accessible out of the 
//	class in child class, if public then accessible out of the package anywhere but need to complex code in every class so better way make it 
//	private and create its method as private static and return its object  
	private static Connection con;
	private static PreparedStatement stmt;
	private static ResultSet rs;
	
//	public static void main (String x[])
//	{
//		new DBConfig();
//	}
	
	private static DBConfig db = null;
//	above statement has a drawback as DBConfig is the parent of other classes and when we create its objects then parent logics which 
//	are present in DBConfig will not be accessible or will not inherit in child class 
	
//	this DBConfig is public but we want to give private access specifier to it to make it a singleton class because it has only single object 
//	and we can avoid the problem of creating multiple objects of child classes which are hitting the database code unnecessary every time
//	public DBConfig()
	private DBConfig()
	{
		try
		{
//			File f = new File(".");
//			"." this annotation will provide us the path till the project ie. HousePricePredictionSystem

//			System.out.println(f.getAbsolutePath());
			
//			String path = (f.getAbsolutePath().substring(0,f.getAbsolutePath().length()-1))+"src\\db.properties+";
//			Above line tells that getAbsolute returns String and it has a method as substring in which we need to pass 0th index and path
//			as getAbsolutePath and .length()-1 provide last index which is "." which we want to remove.
//			+"src\\db.properties+"; this is the remaining path of our project which we brought from file explorer by copying . address
			
//			FileInputStream fin = new FileInputStream(path);
			Properties p = new Properties();
			p.load(PathHelper.fin);
//			System.out.println(PathHelper.fin);
//			this statement will provide the following path -  java.io.FileInputStream@7adf9f5f
//			System.out.println(PathHelper.f.getAbsolutePath());
//			this statement will provide full path when we write public static File f = null in PathHelper Class 
			String driverClassName = p.getProperty("driver.classname");
			String username = p.getProperty("db.username");
			String password = p.getProperty("db.password");
			String url = p.getProperty("db.url");
			System.out.println(driverClassName);
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			This is known as hardcode and we do not need to write this code
			Class.forName(driverClassName);
			con = DriverManager.getConnection(url,username,password);
			if(con!=null)
			{
				System.out.println("Database Connected Successfully.......!");
			}
			else
			{
				System.out.println("Database not Connected........?");
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error is "+ex);
		}
	}
	
//	Singleton class to reuse the DBConfig code without creating object and without inheriting DBConfig class in its child class 
	public static DBConfig getInstance()
	{
		if (db==null)
		{
			db=new DBConfig();
		}
		return db;
	}
//	this statement returns connection object in every class by just calling its object as con  
	public static Connection getConnection()
	{
		return con;
	}
//	this statement returns PreparedStatement object in every class by just calling its object as stmt
	public static PreparedStatement getStatement()
	{
		return stmt;
	}
//	this statement returns ResultSet object in every class by just calling its object as rs
	public static ResultSet getResultSet()
	{
		return rs;
	}
}
