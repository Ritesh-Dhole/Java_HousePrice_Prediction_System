package org.house.predict.repository;

import org.house.predict.config.DBHelper;
public class PredictionRepository extends DBHelper 
{
	public int getMinOfX(int areaId)
	{
		try
		{
			stmt = con.prepareStatement("select avg(ar.areainfeet) from areasquarefeet ar inner join propertymaster p on ar.sqid = p.sqid "
					+ "where p.aid=?");
			stmt.setInt(1, areaId);
			rs = stmt.executeQuery();
			if(rs.next())
			{
				return rs.getInt(1);
			}
			else
			{
				return 0;
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error is "+ex);
			return -1;
		}
	}
	
	public int getMinOfY(int areaId)
	{
		//reference query
		//   select avg(hp.price) from propertyhistoricalprices hp inner join propertymaster pm on hp.pid = pm.pid where pm.aid=3
		return 0;
	}
}
