package org.house.predict.repository;

import org.house.predict.config.DBConfig;

public class AreaMasterRepository{

}
