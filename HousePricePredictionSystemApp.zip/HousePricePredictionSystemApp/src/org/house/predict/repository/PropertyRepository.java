package org.house.predict.repository;

import org.house.predict.config.DBHelper;
import org.house.predict.model.AmenityModel;
import org.house.predict.model.DealModel;
import org.house.predict.model.PropertyModel;
import java.util.*;

public class PropertyRepository extends DBHelper
{
	int pid;
	private List <Object[]>areaWisePropCount;
	
	public int getPropIdAuto()
	{
		try
		{
			stmt = con.prepareStatement("select max(pid) from propertymaster");
			rs = stmt.executeQuery();
			if(rs.next())
			{
				pid = rs.getInt(1);
			}
			return ++pid;		//pid incremented by 1 every time
		}
		catch(Exception ex)
		{
			System.out.println("Error is "+ex);
			return 0;
		}
	}
	public boolean isAddNewProperty(PropertyModel model)
	{
		pid = this.getPropIdAuto();		//this will call pid from getPropIdAuto method and increase by 1 every time
		int pid = model.getPid();
		String propertyAddress = model.getAddress();
		int sqId = model.getSqModel().getId();
		int areaId = model.getAreaModel().getAreaId();
		int cityId = model.getAreaModel().getCityId();
		int nBed = model.getNBed();
		int nBath = model.getNBath();
		System.out.println("Property Master");
		System.out.println("Id"+"\t"+"Address"+"\t\t\t"+"SquareFeet"+"\t"+"Area Id"+"\t"+"City Id"+"\t"+"nBed"+"\t"+"nBath");
		System.out.println((pid + 1)+"\t"+propertyAddress+"\t"+sqId+"\t"+areaId+"\t"+cityId+"\t"+nBed+"\t"+nBath);
		try
		{
			stmt = con.prepareStatement("insert into propertymaster values(?,?,?,?,?,?,?)");
			stmt.setInt(1,pid);
			stmt.setString(2,propertyAddress);
			stmt.setInt(3,sqId);
			stmt.setInt(4,areaId);
			stmt.setInt(5,cityId);
			stmt.setInt(6,nBed);
			stmt.setInt(7,nBath);
			int value = stmt.executeUpdate();
			if(value > 0)
			{
				List<AmenityModel> list = model.getList();
				System.out.println("Amenities");
				int count=0;
				for(AmenityModel m : list)
				{
					stmt= con.prepareStatement("insert into propertyamenityjoin values(?,?)");
					stmt.setInt(1,pid);
					stmt.setInt(2,m.getId());
					value = stmt.executeUpdate();
				}
				DealModel dealModel=model.getDealModel();
				Date d = dealModel.getDate();
				int price = dealModel.getPrice();
				stmt = con.prepareStatement("insert into propertyhistoricalprices values('0',?,?,(select curDate()))");
				stmt.setInt(1,pid);
				stmt.setInt(2,price);
//				stmt.setDate(3,new java.sql.Date(5));
				value = stmt.executeUpdate();
				if (value > 0)
				{ 
					System.out.println("Property Added Successfully.....!");
					return true;
//					System.out.println((dealModel.getTransId()+1)+"\t"+dealModel.getPrice()+"\t"+dealModel.getDate());					
				}
				else
				{
					System.out.println("Property not Added......?");
					return false;
				}
			}
			else
			{
				System.out.println("Some Problem is There");
				return false;
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error is "+ex);
			return false;
		}
/*		List<AmenityModel> list = model.getList();
		System.out.println("Amenities");
		int count=0;
		for(AmenityModel m : list)
		{
			count = count + (m.getId()+1);
			System.out.println(count+"\t"+m.getName());
		}
		System.out.println("Property Amenity Relationship");
		count=0;
		pid++;
		for(AmenityModel m : list)
		{
			count = count + (m.getId()+1);
			System.out.println(pid+"\t"+count);
		}
		System.out.println("Property and Price Relationship");
		DealModel dealModel=model.getDealModel();
		System.out.println((dealModel.getTransId()+1)+"\t"+dealModel.getPrice()+"\t"+dealModel.getDate());	*/
	}
	
	public List<Object[]> getAreaWisePropertyCount(String cityName)
	{
		try
		{
			this.areaWisePropCount = new ArrayList<Object[]>();
			stmt = con.prepareStatement("select a.areaname, count(p.aid) from areamaster a inner join propertymaster p on p.aid = a.aid "
					+ "inner join citymaster c on c.cityid=p.cityid where c.cityname='"+cityName+"' group by a.areaname");
			rs=stmt.executeQuery();
			while(rs.next())
			{
				Object obj[] = new Object[] {rs.getString(1), rs.getInt(2)};
				this.areaWisePropCount.add(obj);
			}
			return this.areaWisePropCount;
		}
		catch(Exception ex)
		{
			System.out.println("Error is "+ex);
			return null;
		}
	}
}
