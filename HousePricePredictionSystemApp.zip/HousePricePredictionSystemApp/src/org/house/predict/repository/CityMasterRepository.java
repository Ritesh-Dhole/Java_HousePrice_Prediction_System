package org.house.predict.repository;

import org.house.predict.config.DBConfig;
import org.house.predict.config.DBHelper;
import org.house.predict.config.PathHelper;
import org.house.predict.model.AreaMasterModel;
import org.house.predict.model.CityMasterModel;

import com.mysql.cj.jdbc.CallableStatement;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import java.sql.*;
//	we add DBHelper class in which we have written the DBConfig.Instance which holds all the database path	
public class CityMasterRepository extends DBHelper	
{
	
//	private DBConfig db = DBConfig.getInstance();
//	if we want to add database path in one line then we can add above line in every class but if we dont want to write even above single 
//	line then we will create a seperate DBHelper class and write database path once
	
//	here we create object of List to fetch the bulk data from database
	private List<CityMasterModel> list = new ArrayList<CityMasterModel>();
	private int areaid=0;
	private List<Object[]> cityWiseAreaCountList;
	private  LinkedHashMap<String,Integer> map;
	private LinkedHashMap <String,ArrayList<String>> cityWiseAreaNameMap;
	
//	1.  this method can add city in database table name as citymaster and get data from CityMasterModel class 
	public boolean isAddNewCity(CityMasterModel model)
	{
		try
		{
//			here database is not accessible because connection, preparedstatement and resultset are protected in DBConfig class 
//			and we can make them public but it is very tedious task to write such complex code every time shown below 
//			this.db.stmt = this.db.con.prepareStatement("");
			
//			so we will make it private and write below statement
			stmt = con.prepareStatement("insert into citymaster values('0',?)");
			stmt.setString(1,model.getCityName());
//			here we pass 1 because we have only one parameter in Query denoted by ?  
			int value = stmt.executeUpdate();		
//			if value added successfully in executeUpdate then return 1 otherwise return 0;
			return value>0?true:false;
		}
		catch(Exception ex)
		{
			System.out.println("Error is"+ex);
		}
		return false;
	}
	
//	2.  In This function we use Collection because we dont know that how much records are present in Database, we could use Array but it will get complex
	public List<CityMasterModel> getAllCities()
	{
//		we write CityMasterModel inside Generics to avoid ClassCastException at runtime and List will only store the references of CityMasterModel
//		and each one row in database indicates each object in the code.
		try
		{
			stmt=con.prepareStatement("select *from citymaster");
			rs=stmt.executeQuery();
			while(rs.next())
			{
				CityMasterModel model = new CityMasterModel();
				model.setCityId(rs.getInt(1));
				model.setCityName(rs.getString(2));
				list.add(model);
			}
			return list.size() > 0 ? list : null;
		}
		catch(Exception ex)
		{
			System.out.println("Error is "+ex);
			return null;
		}
	}
	
//	3.  This Method is used to add Bulk Data coming from database manually or via .csv file
	public boolean isAddBulkCities()
	{
		try
		{
			FileReader fr = new FileReader(PathHelper.path + "city.csv");
			BufferedReader br = new BufferedReader(fr);
			String line=null;
			int value=0;
			while((line=br.readLine())!=null)
			{
				String data[] = line.split(",");
				stmt = con.prepareStatement("insert into citymaster values('0',?)");
				stmt.setString(1,data[1]);		//data[1] because we dont want to use id of the "city.csv" file only name of city will be used
				value=stmt.executeUpdate();
			}
			return value>0?true:false;
		}
		catch(Exception ex)
		{
			System.out.println("Error is "+ex);
			return false;
		} 
	}
	
//	4.  This method is used to get City Name by city Id
	public int getCityId(String cityname)
	{
		try
		{
			stmt=con.prepareStatement("select cityid from citymaster where cityname=?");
			stmt.setString(1,cityname);
			rs=stmt.executeQuery();
			if(rs.next())
			{
				return rs.getInt(1);		//if city present in database table then return it
			}
			else
			{
				return -1;			//city not present in database table
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error is "+ex);
			return -1;
		}
	}
	
//	5.  This Method is used to apply manual logic to get Area Id Automatically without using auto_increment in Database
	public int getAreaIdAutomatic()
	{
		try
		{
			stmt = con.prepareStatement("select max(aid) from areamaster");
			rs=stmt.executeQuery(); 
			if(rs.next())
			{
				this.areaid=rs.getInt(1);
			}
			++areaid;
			return areaid;
		}
		catch(Exception ex)
		{
			 return 0;
		}
	}
	
//	6.  This Method iis used to add new Area in database according to the cityname by creating procedure in database and just calling here
	public boolean isAddArea(AreaMasterModel areamodel)
	{
		try
		{
//			stmt = con.prepareStatement("insert into areamaster values(?,?)");
//			stmt.setInt(1,areamodel.getAreaId());
//			stmt.setString(2,areamodel.getAreaName());
//			int value = stmt.executeUpdate();
//			if(value>0)
//			{
//				stmt = con.prepareStatement("insert into cityareajoin values(?,?)");
//			}
//			instead of writing above code we create procedure in MySQL Database with two insert statements of areamaster and cityareajoin shown below
//			and call them in code by CallableStatement
			
//			mysql> delimiter $$
//			mysql> create procedure savearea(arid int(5),arname varchar(200),ctid int(5))
//			    -> begin
//			    -> insert into areamaster values(arid,arname);
//			    -> insert into cityareajoin values(ctid,arid);
//			    -> end
//			    -> $$
		 	CallableStatement cstmt =  ((CallableStatement) con.prepareCall("{call savearea(?,?,?)}"));
			cstmt.setInt(1,areamodel.getAreaId());
			cstmt.setString(2,areamodel.getAreaName());
			cstmt.setInt(3,areamodel.getCityId());
			boolean b = cstmt.execute();		//cstmt.execute returns false if executed and returns true when not executed
			return !b;		//return !b means !false means true means 
		}
		catch(Exception ex)
		{
			System.out.println("Error is "+ex);
			return false;
		}
	}
	
//	7. We use List Collection because it stores infinite Data coming from database and Object[] array because it store any type of Data(String,Int)
	
	/*public List <Object[]> getCityWiseCount()
	{
//		we will create Queries in MySQL(Backend) and will just call them by repository
		 try
		 {
			 this.cityWiseAreaCountList = new ArrayList<Object[]>();
//			 this will call current running objects and store in new ArrayList Object[] array  
			 stmt = con.prepareStatement("select cm.cityname,count(cm.cityid) as 'CityCount' from citymaster cm inner join cityareajoin caj on "
			 		+ "cm.cityid=caj.cityid inner join areamaster am on am.aid=caj.aid group by cm.cityid;");
			 rs=stmt.executeQuery();
			 while(rs.next())
			 {
				 Object obj[] = new Object[] {rs.getString(1),rs.getInt(2)};
//				 Dynamic Initialization of array
				 this.cityWiseAreaCountList.add(obj);
			 }
			 return this.cityWiseAreaCountList;
		 }
		 catch (Exception ex)
		 {
			 System.out.println("Error is "+ex);
			 return null;
		 }
	}*/
	
//													OR
	
//	7.  We can also use HashMap instead of List to store the database value in form of key and value pair
	public LinkedHashMap<String,Integer> getCityWiseCount()
	{
//		we will create Queries in MySQL(Backend) and will just call them by repository
		 try
		 {
			 map = new LinkedHashMap<String,Integer>();
			 this.cityWiseAreaCountList = new ArrayList<Object[]>();
//			 this will call current running objects and store in new ArrayList Object[] array  
			 stmt = con.prepareStatement("select cm.cityname,count(cm.cityid) as 'CityCount' from citymaster cm inner join cityareajoin caj on "
			 		+ "cm.cityid=caj.cityid inner join areamaster am on am.aid=caj.aid group by cm.cityid;");
			 rs=stmt.executeQuery();
			 while(rs.next())
			 {  
				 map.put(rs.getString(1),rs.getInt(2));
//				 data stored in key and value pair where key(cityname) is unique and value(citycount) may be duplicated
			 }
			 return map; 
		 }
		 catch (Exception ex)
		 {
			 System.out.println("Error is "+ex);
			 return null;
		 }
	}
	
//	8.  This Method is used to fetch all Area names wrt Cites so String is the key for CityName and ArrayList is the value for all Areas of that City
	
	public LinkedHashMap<String,ArrayList<String>> getCityWiseAreaNames()
	{
		try
		{
			this.cityWiseAreaNameMap = new LinkedHashMap<String,ArrayList<String>>();
			stmt=con.prepareStatement("select cityname from citymaster");
			rs=stmt.executeQuery();
			while(rs.next())
			{
				String cityName=rs.getString(1);
				PreparedStatement stmt1 = con.prepareStatement("select am.areaname as 'Area' from areamaster am inner join "
						+ "cityareajoin caj on am.aid=caj.aid inner join citymaster cm on caj.cityid=cm.cityid where cm.cityname =?");
//				stmt1.setString(1,rs.getString(1));
				stmt1.setString(1,cityName);
				ResultSet rs1 = stmt1.executeQuery();
				ArrayList <String>areaNames = new ArrayList<String>();
				while(rs1.next())
				{
					areaNames.add(rs1.getString(1));
				}
				this.cityWiseAreaNameMap.put(cityName,areaNames);
			}
			return this.cityWiseAreaNameMap;
		}
		catch(Exception ex)
		{
			System.out.println("Error is"+ex);
			return null; 
		}
	}
	
//	9.   This method will return areaName by its Id Wherever it is called 
	public int getAreaIdByName(AreaMasterModel model)
	{
		try
		{
			stmt=con.prepareStatement("select am.aid from areamaster am inner join cityareajoin caj on am.aid=caj.aid inner join citymaster cm "
					+ "on cm.cityid=caj.cityid where am.areaname=? and cm.cityname=?");
			stmt.setString(1,model.getAreaName());
			stmt.setString(2,model.getCityName());

			rs=stmt.executeQuery();
			if(rs.next())
			{
				return rs.getInt(1);
			}
			else
			{
				return 0;
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error is"+ex);
			return -1;
		}  
	}
	// 10. This method all areas according to the city name
	public LinkedHashMap<String,ArrayList<String>> getAreasByCityName(String cityName)
	{
		try
		{
			this.cityWiseAreaNameMap = new LinkedHashMap<String,ArrayList<String>>();
	
				PreparedStatement stmt1 = con.prepareStatement("select am.areaname as 'Area' from areamaster am inner join "
						+ "cityareajoin caj on am.aid=caj.aid inner join citymaster cm on caj.cityid=cm.cityid where cm.cityname =?");
//				stmt1.setString(1,rs.getString(1));
				stmt1.setString(1,cityName);
				ResultSet rs1 = stmt1.executeQuery();
				ArrayList <String>areaNames = new ArrayList<String>();
				while(rs1.next())
				{
					areaNames.add(rs1.getString(1));
				}
				this.cityWiseAreaNameMap.put(cityName,areaNames);
			
			return this.cityWiseAreaNameMap;
		}
		catch(Exception ex)
		{
			System.out.println("Error is"+ex);
			return null; 
		}
	}
}